#ifndef RANDOM_H
#define RANDOM_H

void initRandom();
int random(int low, int high);

#endif